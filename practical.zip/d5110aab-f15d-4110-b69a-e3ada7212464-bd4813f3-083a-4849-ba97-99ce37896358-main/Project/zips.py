import shutil

shutil.make_archive("./data", "zip", "./data")

print("done")